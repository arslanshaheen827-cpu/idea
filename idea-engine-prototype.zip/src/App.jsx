import React, { useState } from "react";

export default function App() {
  const [screen, setScreen] = useState("dashboard");
  const [ideas, setIdeas] = useState([
    { id: 1, title: "Curbside recycling for single-use plastic", date: "Oct 12", status: "In Progress", text: "" },
    { id: 2, title: "Boosting local tourism with AR", date: "Sep 30", status: "Completed", text: "" },
  ]);
  const [draft, setDraft] = useState("");
  const [currentIdea, setCurrentIdea] = useState(null);
  const [expansions, setExpansions] = useState([]);
  const [feasibility, setFeasibility] = useState(null);
  const [experiments, setExperiments] = useState([]);
  const [loading, setLoading] = useState(false);

  function startNewIdea() {
    setDraft("");
    setExpansions([]);
    setFeasibility(null);
    setExperiments([]);
    setCurrentIdea(null);
    setScreen("capture");
  }

  function saveDraftAsIdea() {
    const id = Date.now();
    const title = draft.length > 40 ? draft.substring(0, 40) + "..." : draft || "Untitled idea";
    const idea = { id, title, date: new Date().toLocaleDateString(), status: "In Progress", text: draft };
    setIdeas([idea, ...ideas]);
    setCurrentIdea(idea);
    setScreen("expansion");
    generateExpansions(draft);
  }

  function generateExpansions(text) {
    setLoading(true);
    setTimeout(() => {
      const base = text || "A new idea";
      const generated = [
        `${base} — Business model: subscription or B2B service`,
        `${base} — Tech model: autonomous fleet + APIs`,
        `${base} — Creative twist: community co-op and local partners`,
      ];
      setExpansions(generated);
      setLoading(false);
      generateFeasibility(base);
      generateExperiments(base);
    }, 800);
  }

  function generateFeasibility(text) {
    setFeasibility({ cost: "Medium", time: "Short", risk: "High", notes: "Regulatory hurdles may apply." });
  }

  function generateExperiments(text) {
    const ex = [
      { id: 1, title: "Make a 1-page landing page", done: false },
      { id: 2, title: "Run a poll on social media", done: false },
      { id: 3, title: "Talk to 5 potential users", done: false },
    ];
    setExperiments(ex);
  }

  function openIdea(idea) {
    setCurrentIdea(idea);
    setScreen("expansion");
    setExpansions([]);
    generateExpansions(idea.text || idea.title);
  }

  return (
    <div className="min-h-screen bg-gray-100 p-6 font-sans">
      <div className="max-w-xl mx-auto bg-white rounded-2xl shadow-md p-5">
        <header className="flex items-center justify-between mb-4">
          <h1 className="text-xl font-semibold">Idea Engine</h1>
          <button onClick={startNewIdea} className="rounded-lg px-3 py-1 border">+ New Idea</button>
        </header>

        {screen === "dashboard" && (
          <ul className="space-y-3">
            {ideas.map((i) => (
              <li key={i.id} className="p-3 border rounded flex justify-between items-center">
                <div>
                  <div className="font-medium">{i.title}</div>
                  <div className="text-xs text-gray-500">{i.date} • {i.status}</div>
                </div>
                <button onClick={() => openIdea(i)} className="text-sm px-2 py-1 border rounded">Open</button>
              </li>
            ))}
          </ul>
        )}

        {screen === "capture" && (
          <div className="space-y-4">
            <textarea value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Type your idea..." className="w-full p-3 h-40 border rounded resize-none" />
            <button onClick={saveDraftAsIdea} className="px-3 py-1 bg-black text-white rounded">Next</button>
          </div>
        )}

        {screen === "expansion" && (
          <div className="space-y-4">
            <div className="font-medium">Expansions</div>
            {loading ? <div>Generating…</div> : expansions.map((e, idx) => <div key={idx} className="p-3 border rounded">{e}</div>)}
            <button onClick={() => setScreen("feasibility")} className="px-3 py-1 bg-black text-white rounded">Feasibility</button>
          </div>
        )}

        {screen === "feasibility" && feasibility && (
          <div className="space-y-4">
            <div>Cost: {feasibility.cost}</div>
            <div>Time: {feasibility.time}</div>
            <div>Risk: {feasibility.risk}</div>
            <div>{feasibility.notes}</div>
            <button onClick={() => setScreen("experiments")} className="px-3 py-1 bg-black text-white rounded">Next</button>
          </div>
        )}

        {screen === "experiments" && (
          <div className="space-y-4">
            <ul className="space-y-2">
              {experiments.map((ex) => (
                <li key={ex.id} className="p-3 border rounded flex justify-between">
                  <span>{ex.title}</span>
                  <button onClick={() => setExperiments(experiments.map(e => e.id === ex.id ? { ...e, done: !e.done } : e))} className="text-sm border px-2 rounded">{ex.done ? "Undo" : "Done"}</button>
                </li>
              ))}
            </ul>
          </div>
        )}

      </div>
    </div>
  );
}
